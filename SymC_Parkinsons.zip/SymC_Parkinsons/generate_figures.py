import os, numpy as np, matplotlib.pyplot as plt
from matplotlib.colors import LogNorm

def savefig(path):
    plt.tight_layout()
    plt.savefig(path, dpi=200, bbox_inches="tight")
    plt.close()

def main(outdir="figs"):
    os.makedirs(outdir, exist_ok=True)

    # Fig 1: chi regime map
    x = np.linspace(0.4, 1.6, 400); y = np.zeros_like(x)
    plt.figure(figsize=(7,2))
    plt.plot(x, y)
    plt.fill_between(x, -0.1, 0.1, where=x<0.8, alpha=0.2, step="mid")
    plt.fill_between(x, -0.1, 0.1, where=(x>=0.8)&(x<=1.0), alpha=0.4, step="mid")
    plt.fill_between(x, -0.1, 0.1, where=x>1.2, alpha=0.2, step="mid")
    plt.axvline(0.8, linestyle="--"); plt.axvline(1.0, linestyle="--"); plt.axvline(1.2, linestyle="--")
    plt.text(0.6, 0.12, "Underdamped\n(tremor)", ha="center", va="bottom")
    plt.text(0.9, 0.12, "Adaptive window\noptimal", ha="center", va="bottom")
    plt.text(1.4, 0.12, "Overdamped\n(rigidity)", ha="center", va="bottom")
    plt.ylim(-0.15, 0.3); plt.xlim(0.4, 1.6); plt.yticks([])
    plt.xlabel(r"$\chi$ (damping ratio)")
    savefig(os.path.join(outdir, "fig1_regime_map.png"))

    # Fig 2: Tremor-like oscillation and envelope
    fs = 200
    t = np.linspace(0, 10, fs*10)
    omega = 2*np.pi*5.0; gamma_true = 2.0
    signal = np.cos(omega*t)*np.exp(-gamma_true*t) + 0.05*np.random.randn(t.size)
    env = np.exp(-gamma_true*t)
    chi_true = gamma_true/(2*abs(omega))
    plt.figure(figsize=(8,3))
    plt.plot(t, signal, linewidth=1)
    plt.plot(t, env, linestyle="--")
    plt.plot(t, -env, linestyle="--")
    plt.xlabel("Time (s)"); plt.ylabel("Amplitude")
    plt.title(r"Tremor-like decay, $\omega/2\pi=5$ Hz, $\chi=%.2f$" % chi_true)
    savefig(os.path.join(outdir, "fig2_tremor_decay.png"))

    # Fig 3: Tremor spectrogram
    plt.figure(figsize=(7,3))
    Pxx, freqs, bins, im = plt.specgram(signal, NFFT=256, Fs=fs, noverlap=128)
    plt.xlabel("Time (s)"); plt.ylabel("Frequency (Hz)")
    plt.title("Example spectrogram (tremor segment)")
    savefig(os.path.join(outdir, "fig3_tremor_spectrogram.png"))

    # Fig 4: Gait ACF with exponential fit
    n = 1000; rho = 0.95
    xg = np.zeros(n); noise = np.random.randn(n)
    for i in range(1,n): xg[i] = rho*xg[i-1] + 0.2*noise[i]
    def acf(x, maxlag=100):
        x = x - np.mean(x)
        c = np.correlate(x, x, mode='full'); c = c[c.size//2:]
        c = c / c[0]; return c[:maxlag+1]
    lags = 80
    ac = acf(xg, lags)
    tau = np.arange(lags+1)/2.0
    mask = (ac>0.05)
    gamma_hat = -np.polyfit(tau[mask], np.log(ac[mask]), 1)[0]
    plt.figure(figsize=(6,3))
    plt.plot(tau, ac, marker="o", linestyle="")
    plt.plot(tau, np.exp(-gamma_hat*tau), linestyle="--")
    plt.xlabel("Lag (s)"); plt.ylabel("Autocorrelation")
    plt.title(r"Gait ACF with exponential fit, $\hat{\gamma}=%.2f$ s$^{-1}$" % gamma_hat)
    savefig(os.path.join(outdir, "fig4_gait_acf.png"))

    # Fig 5: LFP beta burst + envelope
    fs2 = 500
    t2 = np.linspace(0, 2.5, int(fs2*2.5))
    omega_beta = 2*np.pi*20.0; gamma_beta = 6.0
    burst = np.cos(omega_beta*t2)*np.exp(-gamma_beta*t2) + 0.05*np.random.randn(t2.size)
    envb = np.exp(-gamma_beta*t2)
    chi_beta = gamma_beta/(2*abs(omega_beta))
    plt.figure(figsize=(8,3))
    plt.plot(t2, burst, linewidth=1)
    plt.plot(t2, envb, linestyle="--")
    plt.plot(t2, -envb, linestyle="--")
    plt.xlabel("Time (s)"); plt.ylabel("Amplitude")
    plt.title(r"LFP beta burst example, $\chi=%.2f$" % chi_beta)
    savefig(os.path.join(outdir, "fig5_lfp_beta_burst.png"))

    # Fig 6: Therapy response U-curve
    chi = np.linspace(0.5, 1.5, 200)
    symptom = (chi-0.9)**2 + 0.05
    plt.figure(figsize=(6,3))
    plt.plot(chi, symptom)
    plt.axvline(0.8, linestyle="--"); plt.axvline(1.0, linestyle="--")
    plt.xlabel(r"$\chi$ (damping ratio)"); plt.ylabel("Symptom score (arb.)")
    plt.title("Dose/DBS response curve vs. damping ratio")
    savefig(os.path.join(outdir, "fig6_therapy_u_curve.png"))

    # Fig 7: Simple clinical trial schema
    plt.figure(figsize=(8,3)); plt.axis("off")
    plt.text(0.1, 0.5, "PD Cohort\\n(n=120)", ha="center", va="center", bbox=dict(boxstyle="round", fc="none"))
    plt.text(0.4, 0.5, "Randomize 1:1", ha="center", va="center")
    plt.arrow(0.2, 0.5, 0.12, 0.0, length_includes_head=True, head_width=0.02)
    plt.arrow(0.6, 0.5, -0.12, 0.0, length_includes_head=True, head_width=0.02)
    plt.text(0.7, 0.75, "Arm A\\n$\\chi$-targeted DBS", ha="center", va="center", bbox=dict(boxstyle="round", fc="none"))
    plt.text(0.7, 0.25, "Arm B\\nStandard DBS", ha="center", va="center", bbox=dict(boxstyle="round", fc="none"))
    plt.text(0.9, 0.75, "Primary: UPDRS\\nSecondary: $\\chi$ var., FOG", ha="left", va="center")
    plt.text(0.9, 0.25, "Primary: UPDRS\\nSecondary: $\\chi$ var., FOG", ha="left", va="center")
    savefig(os.path.join(outdir, "fig7_trial_schema.png"))

if __name__ == "__main__":
    main()
