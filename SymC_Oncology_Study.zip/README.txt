SymC Translational Roadmap v1 (LaTeX All-in-One)
--------------------------------------------------
Files:
- SymC_Translational_Roadmap_v1.tex   (compiles standalone; embeds symc_refs.bib)
- symc_refs.bib                       (editable BibTeX with 45 placeholders)
- compile.sh

Compile:
  pdflatex SymC_Translational_Roadmap_v1.tex
  bibtex   SymC_Translational_Roadmap_v1
  pdflatex SymC_Translational_Roadmap_v1.tex
  pdflatex SymC_Translational_Roadmap_v1.tex

Generated: 2025-10-24T12:03:40.535673Z
