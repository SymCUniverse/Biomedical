#!/usr/bin/env bash
set -e
pdflatex SymC_Translational_Roadmap_v1.tex
bibtex SymC_Translational_Roadmap_v1
pdflatex SymC_Translational_Roadmap_v1.tex
pdflatex SymC_Translational_Roadmap_v1.tex
echo "Built SymC_Translational_Roadmap_v1.pdf"
